# Proto v2 (iPad 最小セット)

これは **Vercel にそのまま置ける最小構成** です。ビルド不要、設定ファイル不要。

## 構成
- `/index.html` … トップページ（リンク付き）
- `/api/hello.ts` … サーバーレス関数（JSONを返す）

## 使い方（iPad）
1. このZIPをダウンロード → ファイルアプリで解凍
2. GitHub でリポジトリを作成 → **Add file → Upload files**
3. `proto-v2` フォルダの **中身**（`index.html` と `api/hello.ts` と `README.md`）をアップロード
4. Vercel でそのリポジトリを Import → **Deploy**
5. 公開URLへアクセス → `/api/hello` が `{ "message": "Hello from Proto v2!" }` を返せば成功

## 次のステップ
- 画像アップロードや決済などは、後から `/api/...` にファイルを足していけば拡張できます。
